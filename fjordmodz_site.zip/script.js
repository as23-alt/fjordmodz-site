
function openContactForm() {
  const email = "itpdtimis@gmail.com";
  const message = prompt("Write your question:");
  if (message) {
    alert("Your message has been sent to " + email);
  }
}
document.getElementById("login-btn").addEventListener("click", function () {
  window.location.href = "https://id.cfx.re/login";
});
